create definer = root@localhost trigger setChangetime
    before update
    on myfile
    for each row
BEGIN
    SET NEW.changetime = NOW();
END;

